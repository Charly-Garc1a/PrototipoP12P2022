/*
SEGUNDO PARCIAL - SERIE 3
CHARLY ALEXANDER GARCIA GOMEZ
9959-19-5853
*/
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h> // getch
#include <vector>

/*Librerias para la Fecha y La Hora*/
#include <iomanip>
#include <ctime>

#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <cstdlib>
#include <windows.h>

#define ENTER 13
#define BACKSPACE 8
#define INTENTOS 3
typedef struct {
   int  cuenta;
   char nomalum[40];
   char gmail[40];
   int primpar;
   int segpar;
   int estatus;
   int direccion;
   int nit;
}


Alumno;
void  MenuPrincipal(void);
void  SubMenu(void);
void  Crear(void);
void  Imprimir(void);
void  Anexar (void);
void  Modificar(void);
void  Borrar(void);

void  Catalogos(void);
void  Procesos(void);
void  MenuInformes(void);



void MenuCliente(void);
void MenuProducto(void);
void MenuMarcas(void);
void MenuLineas(void);

void CrearCliente(void);
void AnexarCliente(void);
void ImprimirCliente(void);

void CrearProducto(void);
void AnexarProducto(void);
void ImprimirProducto(void);

void CrearMarca(void);
void AnexarMarca(void);
void ImprimirMarca(void);

void CrearLinea(void);
void AnexarLinea(void);
void ImprimirLinea(void);

int op,cent;
#include <iostream>
#include <fstream>

using namespace std;

//LOGIN//
int main(){




vector<string> usuarios;
    vector<string> claves;

    // Se a�aden usuarios al vector
    usuarios.push_back("Charly");

    // Se a�aden claves al vector
    claves.push_back("123");


    string usuario, password;

    int contador = 0;
    bool ingresa = false;

    do
    {

        system("cls");
        printf("\n--------------------CHARLY ALEXANDER GARCIA GOMEZ--------------------------\n");
        auto t = std::time(nullptr);
        auto tm = *std::localtime(&t);
        std::cout << std::put_time(&tm, "\n\t\t\t\t%d-%m-%Y %H-%M-%S\n") << std::endl;
        printf("\n---------------------------------------------------------------------------\n");
        printf("\n");
        Sleep(300);
        cout << "\t\t\t\tLOGIN DE USUARIO" << endl;
        cout << "\t\t\t\t----------------" << endl;
        cout << "\n\t\t\tUsuario: ";
        Sleep(200);
        getline(cin, usuario);

        char caracter;

        cout << "\t\t\tPassword: ";
        caracter = getch();

        password = "";

        while (caracter != ENTER)
        {

            if (caracter != BACKSPACE)
            {
                password.push_back(caracter);
                cout << "*";
            }
            else
            {
                if (password.length() > 0)
                {
                    cout << "\b \b";
                    password = password.substr(0, password.length() - 1);
                }
            }

            caracter = getch();
        }

        for (int i = 0; i < usuarios.size(); i++)
        {
            if (usuarios[i] == usuario && claves[i] == password)
            {
                ingresa = true;
                break;
            }
        }

        if (!ingresa)
        {
            cout << "\n\n\t\t\tEl usuario y/o password son incorrectos" << endl;
            cin.get();
            contador++;
        }

    } while (ingresa == false && contador < INTENTOS);

    if (ingresa == false)
    {
        cout << "\n\tUsted no pudo ingresar al sistema. ADIOS" << endl;
    }
    else
    {
        system("cls");
        cout << "\n\n\t\t\t\t\t----------\2--------------" << endl;
        MenuPrincipal();

    }

    cin.get();

    return 0;

}

//MENU PRINCIPAL//
void MenuPrincipal(void){
      while(cent<=6){
            printf("\n---------------------------------------------------------------------------\n");
            printf("\t\t\t\tCHARLY GARCIA 9959-19-5853\n");
            printf("\t\t\t\tBIENVENDIO AL MENU PRINCIPAL\n");
            printf("\n\t\t\t\t1.- Catalogos\n");
            printf("\n\t\t\t\t2.- Procesos\n");
            printf("\n\t\t\t\t3.- Informes\n");
            printf("\n\t\t\t\t4.- Salir del menu\n");
            printf("\n\n\t\t\t\tOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  Catalogos();
               break;
               case 2:
                  Procesos();
               break;
               case 3:
                  MenuInformes();
               break;
               case 4:
                  cent=7;
               break;
               default:
                  system("cls");
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();

}

//MENU DE CATALOGO//
void Catalogos(void){
    system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de CATALOGO");
            printf("\n\n1.- Crear archivo y crear un nuevo Vendedor");
            printf("\n\n2.- Visualizar la lista existente de Vendedores");
            printf("\n\n3.- A�adir nuevo vendedor al archivo existente");
            printf("\n\n4.- Modificar el registro de un vendedor");
            printf("\n\n5.- Borrar el registro de Vendedor");
            printf("\n\n6.- Salir al Menu Principal");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  Crear();
               break;
               case 2:
                  Imprimir();
               break;
               case 3:
                  Anexar();
               break;
               case 4:
                  Modificar();
               break;
               case 5:
                  Borrar();
               break;
               case 6:
                  MenuPrincipal();
               break;
               default:
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();
}

//FUNCION PARA CREAR EL ARCHIVO//
void Crear(void){
   FILE *fp;
   Alumno alm;
   // Creacion del archivo y guardar datos
   if(!(fp=fopen("registro.dat","wb")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      system("cls");
      printf("\tELIGIO LA OPCION 1: CREAR ARCHIVO y A�ADIR UN VENDEDOR");
      printf("\n\nIntroduce el Nombre del Vendedor: ");
      gets(alm.nomalum);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce la Direccion por Zona: ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el numero de Telefono:  ");
      scanf("%d",&alm.segpar);
      printf("\nIntroduce el numero de Nit:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el numero Estatus del Vendedor 1(Activo) 0(Inactivo):");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!REGISTRO REALIZADO CON EXITO!!!");
      printf("\nPresiona cualquier tecla para regresar al menu principal...");
      getch();
      fclose(fp);
      Catalogos();
   }
}

//FUNCION PARA IMPRIMIR EL REGISTRO DE VENDEDORES//
void Imprimir(void){
   FILE *fp;
   Alumno  alm;
   int n;
   if(!(fp=fopen("registro.dat","rb")))
   	printf("Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 2:IMPRIMIR REGISTRO DE VENDEDORES\n");
      printf("\n\n\t\t R E G I S T R O  D E V E N D E D O R E S \n");
      printf("\n---------------------------------------------------------------------------\n");
      printf("VENDEDOR \tCODIGO \t DIRECCION \tTELEFONO\tNIT\tESTATUS");
      printf("\n-------------------------------------------------------------------------\n\n");
      while ((n=fread(&alm, sizeof(alm),1, fp))!=0){
         printf("%s \t\t",alm.nomalum);
         printf("%d \t\t",alm.cuenta);
         printf("%d \t",alm.direccion);
         printf("%d \t",alm.segpar);
         printf("%d \t",alm.nit);
         printf("%d \t\n",alm.estatus);
      }
      printf("\n-------------------------------------------------------------------------\n\n");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

//FUNCION PARA ANEXAR DATOS AL REGISTRO DE EMPLEADO//
void Anexar(void){
   FILE *fp;
   Alumno	alm;

   system("cls");
   printf("\tELIGIO LA OPCION 3: ANEXAR VENDEDOES AL ARCHIVO");
   printf("\n\n!!Se anexaran nuevos EMPLEADOS al registro de Vendedores.dat!!\n");
   if(!(fp=fopen("registro.dat","ab")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      printf("\n\nIntroduce el nombre del Vendedor: ");
      gets(alm.nomalum);
      fflush(stdin);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce la Direccion por Zona:  ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el Numero de Telefono:  ");
      scanf("%d",&alm.segpar);
      printf("\nIntroduce el Numero de NIT:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el Estatus del Vendedor 1(Activo) 0(Inactivo):  ");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!ANEXO REALIZADO CON EXITO!!!");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

//FUNCION PARA MODIFICAR UN REGISTRO CON BUSQUEDA
void Modificar(void){
   FILE *fp;
   Alumno alm;
   int n,c,opc;

   if(!(fp=fopen("registro.dat","r+b")))
   	printf("\n Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 4: MODIFICAR EL REGISTRO DE VENDEDORES");
      printf("\n\nIntroduzca el Codigo de Vendedor: ");
      scanf("%d",&alm.cuenta);
      c=alm.cuenta;
      while ((n=fread(&alm, sizeof(alm), 1, fp))!=0 && alm.cuenta!=c);
      if (alm.cuenta!=c)
         printf("No existe el Codigo: %d ",c);
      else{
         system("cls");
         printf("\n!!Se encontro el Vendedor!!");
         printf("\n�Que desea cambiar?, Seleccione una opcion");
         printf("\n\n1.-Nombre");
         printf("\n\n2.-Codigo");
         printf("\n\n3.-Direccion");
         printf("\n\n4.-Telefono");
         printf("\n\n5.-NIT");
         printf("\n\n6.-Estatus");
         printf("\n\nIntroduzca opicion: ");
         scanf("%d",&opc);
         switch(opc){
                     case 1:
                        fflush(stdin);
                        printf("\nIntroduzca el nuevo nombre: ");
                        gets(alm.nomalum);
                     break;
                     case 2:
                        printf("\nIntroduza el nuevo Codigo: ");
                        scanf("%d",&alm.cuenta);
                     break;
                     case 3:
                        printf("\nIntroduzca la nueva Direccion: ");
                        scanf("%d",&alm.direccion);
                     break;
                     case 4:
                        printf("\nIntroduzca el numero de Telefono:  ");
                        scanf("%d",&alm.segpar);
                     break;
                     case 5:
                        printf("\nIntroduzca el numero de NIT:  ");
                        scanf("%d",&alm.nit);
                     break;
                     case 6:
                        printf("\nIntroduzca el numero de Estatus:  ");
                        scanf("%d",&alm.estatus);
                     break;
                     default:
                        printf("\Error, opcion inexistente");
                     break;
         }
         printf("\nGrabando registro\n");
         fseek(fp,-sizeof(alm),SEEK_CUR);
         fwrite(&alm, sizeof(alm), 1, fp);
         printf("\nRegistro grabado con exito");
         printf("\nPresiona una tecla para continuar...");
         getch();
      }
      fclose(fp);
   }
}

//FUNCION PARA BORRAR REGISTROS DE  EMPLEADOS//
void Borrar(void){
   FILE *fp,*fd;
   Alumno alm;
   int n,c,encontrado=0;
 system("cls");
   printf("\tELIGIO LA OPCION 5: BORRAR EL REGISTRO DE UN VENDEDOR");
   printf("\n\nIngrese el Codigo del Vendedor que desea Eliminar: ");
   scanf("%d",&alm.cuenta);
   c=alm.cuenta;
   if(!(fp=fopen("registro.dat","rb")))
   	printf("\n Error de apuertura del registro");
   else{
      if(!(fd=fopen("auxregis.txt","wb")))
         printf("\n Error,imposible borrar registro, el archivo no existe");
      else{
         while ((n=fread(&alm, sizeof(alm), 1, fp))!=0){
            if(alm.cuenta!=c)
              fwrite(&alm, sizeof(alm), 1, fd);
            else
              encontrado=1;
         }
         fclose(fd);
      }
      fclose(fp);
      if(encontrado){
         system("del registro.dat");
         system("ren auxregis.txt registro.dat");
         printf("\n!!!Registro borrado satisfactoriamente!!!\n");
         printf("\n\nPresiona una tecla para continuar");
         getch();
      }
      else{
         system("del auxregis.txt");
         printf("\n!!!No se entontro ningun alumno con ese numero de cuenta!!!");
         printf("\n\nPresiona una tecla para continuar");
         getch();
      }
   }
}

void Procesos(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de PROCESOS");
            printf("\n\n1.- CLIENTES");
            printf("\n\n2.- PRODUCTOS");
            printf("\n\n3.- MARCAS");
            printf("\n\n4.- LINEAS");
            printf("\n\n6.- Salir al Menu Principal");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  MenuCliente();
               break;
               case 2:
                  MenuProducto();
               break;
               case 3:
                  MenuMarcas();
               break;
               case 4:
                  MenuLineas();
               break;
               case 5:
                  system("cls");
                  MenuPrincipal();
               break;
               default:
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();
}

void MenuCliente(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de CLIENTES");
            printf("\n\n1.- Crear Archivo de CLIENTES");
            printf("\n\n2.- Anexar Clientes Nuevos al Archivo");
            printf("\n\n3.- Salir al Menu Principal");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  CrearCliente();
               break;
               case 2:
                  AnexarCliente();
               break;
               case 3:
                  MenuPrincipal();
               break;
               default:
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();
}

void CrearCliente(void){
FILE *fp;
   Alumno alm;
   // Creacion del archivo y guardar datos
   if(!(fp=fopen("clientes.dat","wb")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      system("cls");
      printf("\tELIGIO LA OPCION 1: CREAR ARCHIVO y A�ADIR UN VENDEDOR");
      printf("\n\nIntroduce el Nombre del Cliente: ");
      gets(alm.nomalum);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce la Direccion por Zona: ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el numero de Telefono:  ");
      scanf("%d",&alm.segpar);
      printf("\nIntroduce el numero de Nit:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el numero Estatus del Vendedor 1(Activo) 0(Inactivo):");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!REGISTRO REALIZADO CON EXITO!!!");
      printf("\nPresiona cualquier tecla para regresar al menu principal...");
      getch();
      fclose(fp);
      MenuPrincipal();
   }
}

void AnexarCliente(void){
FILE *fp;
   Alumno	alm;

   system("cls");
   printf("\tELIGIO LA OPCION 3: ANEXAR CLIENTES AL ARCHIVO");
   printf("\n\n!!Se anexaran nuevos EMPLEADOS al registro de clientes.dat!!\n");
   if(!(fp=fopen("clientes.dat","ab")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      printf("\n\nIntroduce el nombre del cliente: ");
      gets(alm.nomalum);
      fflush(stdin);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce la Direccion por Zona:  ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el Numero de Telefono:  ");
      scanf("%d",&alm.segpar);
      printf("\nIntroduce el Numero de NIT:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el Estatus del Vendedor 1(Activo) 0(Inactivo):  ");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!ANEXO REALIZADO CON EXITO!!!");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void ImprimirCliente(void){
     FILE *fp;
   Alumno  alm;
   int n;
   if(!(fp=fopen("clientes.dat","rb")))
   	printf("Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 2:IMPRIMIR REGISTRO DE CLIENTES\n");
      printf("\n\n\t\t R E G I S T R O  D E V E N D E D O R E S \n");
      printf("\n---------------------------------------------------------------------------\n");
      printf("VENDEDOR \tCODIGO \t DIRECCION \tTELEFONO\tNIT\tESTATUS");
      printf("\n-------------------------------------------------------------------------\n\n");
      while ((n=fread(&alm, sizeof(alm),1, fp))!=0){
         printf("%s \t\t",alm.nomalum);
         printf("%d \t\t",alm.cuenta);
         printf("%d \t",alm.direccion);
         printf("%d \t",alm.segpar);
         printf("%d \t",alm.nit);
         printf("%d \t\n",alm.estatus);
      }
      printf("\n-------------------------------------------------------------------------\n\n");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void MenuProducto(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de PRODUCTOS");
            printf("\n\n1.- Crear Archivo de PRODUCTOS");
            printf("\n\n2.- Anexar Clientes Nuevos al Archivo");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  CrearProducto();
               break;
               case 2:
                  AnexarProducto();
               break;
               default:
                  printf("\nPresiona una tecla para continuar...");
                  getch();
                  MenuPrincipal();
               break;
            }
        system("cls");
        }
        getch();
}

void CrearProducto(void){
FILE *fp;
   Alumno alm;
   // Creacion del archivo y guardar datos
   if(!(fp=fopen("productos.dat","wb")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      system("cls");
      printf("\tELIGIO LA OPCION 1: CREAR ARCHIVO y A�ADIR UN PRODUCTO");
      printf("\n\nIntroduce el Nombre del Producto: ");
      gets(alm.nomalum);
      printf("\nIntroduce el Codigo de Lineas: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Codigo de Marca: ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el numero de Existencia:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el numero Estatus del Vendedor 1(Activo) 0(Inactivo):");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!REGISTRO REALIZADO CON EXITO!!!");
      printf("\nPresiona cualquier tecla para regresar al menu principal...");
      getch();
      fclose(fp);
      MenuPrincipal();
   }
}

void AnexarProducto(void){
FILE *fp;
   Alumno	alm;

   system("cls");
   printf("\tELIGIO LA OPCION 3: ANEXAR PRODUCTOS AL ARCHIVO");
   printf("\n\n!!Se anexaran nuevos PRODUCTOS al registro de productos.dat!!\n");
   if(!(fp=fopen("productos.dat","ab")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      printf("\n\nIntroduce el nombre del PRODUCTO: ");
      gets(alm.nomalum);
      fflush(stdin);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Codigo de Linea:  ");
      scanf("%d",&alm.direccion);
      printf("\nIntroduce el Codigo de Marca:  ");
      scanf("%d",&alm.segpar);
      printf("\nIntroduce el Numero de Existencia:  ");
      scanf("%d",&alm.nit);
      printf("\nIntroduce el Estatus del Producto 1(Activo) 0(Inactivo):  ");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!ANEXO REALIZADO CON EXITO!!!");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void ImprimirProducto(void){
FILE *fp;
   Alumno  alm;
   int n;
   if(!(fp=fopen("productos.dat","rb")))
   	printf("Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 2:IMPRIMIR REGISTRO DE PRODCUTOS\n");
      printf("\n\n\t\t R E G I S T R O  D E  P R O D U C T O S \n");
      printf("\n---------------------------------------------------------------------------\n");
      printf("PRODUCTO \tCODIGO \t COD. LINEA \t COD. MARCA\t EXISTENCIA \tESTATUS");
      printf("\n-------------------------------------------------------------------------\n\n");
      while ((n=fread(&alm, sizeof(alm),1, fp))!=0){
         printf("%s \t\t",alm.nomalum);
         printf("%d \t\t",alm.cuenta);
         printf("%d \t",alm.direccion);
         printf("%d \t",alm.segpar);
         printf("%d \t",alm.nit);
         printf("%d \t\n",alm.estatus);
      }
      printf("\n-------------------------------------------------------------------------\n\n");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void MenuMarcas(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de MARCAS");
            printf("\n\n1.- Crear Archivo de MARCAS");
            printf("\n\n2.- Anexar MARCAS Nuevos al Archivo");
            printf("\n\n6.- Salir al Menu Principal");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  CrearMarca();
               break;
               case 2:
                  AnexarMarca();
               break;
               case 3:
                  system("cls");
                  MenuPrincipal();
               break;
               default:
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();
}

void CrearMarca(void){
FILE *fp;
   Alumno alm;
   // Creacion del archivo y guardar datos
   if(!(fp=fopen("marcas.dat","wb")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      system("cls");
      printf("\tELIGIO LA OPCION 1: CREAR ARCHIVO y A�ADIR MARCAS");
      printf("\n\nIntroduce el Nombre la Marca: ");
      gets(alm.nomalum);
      printf("\nIntroduce el Codigo de Lineas: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Numero Estatus de la Marca 1(Activo) 0(Inactivo):");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!REGISTRO REALIZADO CON EXITO!!!");
      printf("\nPresiona cualquier tecla para regresar al menu principal...");
      getch();
      fclose(fp);
      MenuPrincipal();
   }
}

void AnexarMarca(void){
FILE *fp;
   Alumno	alm;

   system("cls");
   printf("\tELIGIO LA OPCION 3: ANEXAR MARCAS AL ARCHIVO");
   printf("\n\n!!Se anexaran nuevos PRODUCTOS al registro de marcas.dat!!\n");
   if(!(fp=fopen("marcas.dat","ab")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      printf("\n\nIntroduce el nombre del PRODUCTO: ");
      gets(alm.nomalum);
      fflush(stdin);
      printf("\nIntroduce el Codigo: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Estatus del Producto 1(Activo) 0(Inactivo):  ");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!ANEXO REALIZADO CON EXITO!!!");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void ImprimirMarca(void){
FILE *fp;
   Alumno  alm;
   int n;
   if(!(fp=fopen("marcas.dat","rb")))
   	printf("Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 2:IMPRIMIR REGISTRO DE PRODCUTOS\n");
      printf("\n\n\t\t R E G I S T R O  D E  M A R C A S \n");
      printf("\n---------------------------------------------------------------------------\n");
      printf("MARCA \tCODIGO \tESTATUS");
      printf("\n-------------------------------------------------------------------------\n\n");
      while ((n=fread(&alm, sizeof(alm),1, fp))!=0){
         printf("%s \t\t",alm.nomalum);
         printf("%d \t\t",alm.cuenta);
         printf("%d \t\n",alm.estatus);
      }
      printf("\n-------------------------------------------------------------------------\n\n");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void MenuLineas(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de LINEAS");
            printf("\n\n1.- Crear Archivo de LINEAS");
            printf("\n\n2.- Anexar LINEAS Nuevos al Archivo");
            printf("\n\n6.- Salir al Menu Principal");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  CrearLinea();
               break;
               case 2:
                  AnexarLinea();
               break;
               case 3:
                  system("cls");
                  MenuPrincipal();
               break;
               default:
                  printf("\n!!!Error, opcion inexistente!!!");
                  printf("\n Introduce una opcion valida");
                  getch();
               break;
            }
        system("cls");
        }
        getch();
}

void CrearLinea(void){
FILE *fp;
   Alumno alm;
   // Creacion del archivo y guardar datos
   if(!(fp=fopen("lineas.dat","wb")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      system("cls");
      printf("\tELIGIO LA OPCION 1: CREAR ARCHIVO y A�ADIR LINEAS");
      printf("\n\nIntroduce el Nombre la Linea: ");
      gets(alm.nomalum);
      printf("\nIntroduce el Codigo de Lineas: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Numero Estatus de la Linea 1(Activo) 0(Inactivo):");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!REGISTRO REALIZADO CON EXITO!!!");
      printf("\nPresiona cualquier tecla para regresar al menu principal...");
      getch();
      fclose(fp);
      MenuPrincipal();
   }
}

void AnexarLinea(void){
    FILE *fp;
   Alumno	alm;

   system("cls");
   printf("\tELIGIO LA OPCION 3: ANEXAR LINEAS AL ARCHIVO");
   printf("\n\n!!Se anexaran nuevas LINEAS al registro de lineas.dat!!\n");
   if(!(fp=fopen("lineas.dat","ab")))
   	printf("\n Error de apuertura del registro");
   else{
      fflush(stdin);
      printf("\n\nIntroduce el nombre de la Linea: ");
      gets(alm.nomalum);
      fflush(stdin);
      printf("\nIntroduce el Codigo de la Linea: ");
      scanf("%d",&alm.cuenta);
      printf("\nIntroduce el Estatus de la Linea 1(Activo) 0(Inactivo):  ");
      scanf("%d",&alm.estatus);
      fwrite(&alm, sizeof(alm), 1, fp);
      printf("\n!!!ANEXO REALIZADO CON EXITO!!!");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void ImprimirLinea(void){
FILE *fp;
   Alumno  alm;
   int n;
   if(!(fp=fopen("lineas.dat","rb")))
   	printf("Error de apuertura del registro");
   else{
      system("cls");
      printf("\tELIGIO LA OPCION 2:IMPRIMIR REGISTRO DE PRODCUTOS\n");
      printf("\n\n\t\t R E G I S T R O  D E  M A R C A S \n");
      printf("\n---------------------------------------------------------------------------\n");
      printf("LINEA \tCODIGO \tESTATUS");
      printf("\n-------------------------------------------------------------------------\n\n");
      while ((n=fread(&alm, sizeof(alm),1, fp))!=0){
         printf("%s \t\t",alm.nomalum);
         printf("%d \t\t",alm.cuenta);
         printf("%d \t\n",alm.estatus);
      }
      printf("\n-------------------------------------------------------------------------\n\n");
      printf("\nPresiona una tecla para continuar...");
      getch();
      fclose(fp);
   }
}

void MenuInformes(void){
system("cls");
     cent=7;
      while(cent<=7){
            printf("Bienvenido al menu de PROCESOS");
            printf("\n\n1.- IMPRIMIR VENDEDORES");
            printf("\n\n2.- IMPRIMIR CLIENTES");
            printf("\n\n3.- IMPRIMIR PRODUCTOS");
            printf("\n\n4.- IMPRIMIR MARCAS");
            printf("\n\n5.- IMPRIMIR LINEAS");
            printf("\n\nOpcion: ");
            scanf("%d",&op);

            switch(op){
               case 1:
                  Imprimir();
               break;
               case 2:
                  ImprimirCliente();
               break;
               case 3:
                  ImprimirProducto();
               break;
               case 4:
                  ImprimirMarca();
               break;
               case 5:
                  ImprimirLinea();
               break;
               default:
                  printf("\nPresiona una tecla para continuar...");
                  getch();
                  MenuPrincipal();
               break;
            }
        system("cls");
        }
        getch();
}
